import boto3
from PIL import Image
import io
import json
import os
import datetime

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

size_resize = (100,100)
destination_bucket = 'thumnails-storage'
table_name = 'metada_thumbnails'

def send_metada_to_dynamo(metada, ):
    table = dynamodb.Table(table_name)
    response = table.put_item(Item=metada)

    print("Ítem insertado exitosamente:", response)

def read_image(record):
    body = record['body']

    data = json.loads(body)

    bucket = data['bucket']
    file_path = data['file_path']

    response = s3_client.get_object(Bucket=bucket, Key=file_path)
    image_data = response['Body'].read()
    # Acceder a los campos específicos del mensaje

    filename = os.path.basename(file_path)

    print(f"Bucket: {bucket}")
    print(f"Archivo: {file_path}")

    return image_data, bucket, filename, file_path

def save_thumbnail_image(destination_bucket, file_path, data):
    try:
        # Subir la imagen a otro bucket
        s3_client.put_object(
            Bucket=destination_bucket,  # Bucket de destino
            Key=file_path,        # Ruta/Nombre del archivo en el bucket destino
            Body=data,              # Los datos de la imagen que hemos descargado
            ContentType='image/png'
        )
        print(f"Imagen subida exitosamente a")
    except Exception as e:
        print(f"Error al subir la imagen: {e}")
    
    # Obtener metadatos de la imagen
    response = s3_client.head_object(Bucket=destination_bucket, Key=file_path)

    # Extraer el tamaño en bytes
    file_size = response['ContentLength']

    return file_size

def lambda_handler(event, context):

    try:
        # Iterar sobre cada mensaje en el evento
        for record in event['Records']:
            # Leer el cuerpo del mensaje
            image_data, bucket, filename, file_path = read_image(record)

            image = Image.open(io.BytesIO(image_data))
            image.thumbnail(size_resize)  # Redimensionar a 128x128 píxeles

            buffer = io.BytesIO() #Bytes

            # Guardar la imagen en el objeto de BytesIO en el formato que quieras (por ejemplo, PNG)
            image.save(buffer, format='PNG')
            
            # Mover el puntero de vuelta al inicio del archivo en memoria
            buffer.seek(0)

            file_size = save_thumbnail_image(destination_bucket, file_path, buffer)
            buffer.close()
            del buffer

            metada_thumbnail = {"filename": filename,
                                "URL": f"https://{destination_bucket}.s3.amazonaws.com/{file_path}",
                                "size": file_size,
                                "date_created":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                "height": image.size[1],
                                "width": image.size[0],  
                                }
        
            send_metada_to_dynamo(metada_thumbnail)
                                
        return {
            'statusCode': 200,
            'body': 'Mensajes procesados exitosamente'
        }

    except Exception as e:
        print(f"Error procesando el mensaje: {e}")
        return {
            'statusCode': 500,
            'body': f'Error procesando el mensaje: {e}'
        }